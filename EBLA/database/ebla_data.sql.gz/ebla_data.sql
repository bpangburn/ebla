--
-- PostgreSQL database dump
--

\connect - postgres

SET search_path = public, pg_catalog;

--
-- TOC entry 2 (OID 129052)
-- Name: parameter_data_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE parameter_data_seq
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;


--
-- TOC entry 4 (OID 129052)
-- Name: parameter_data_seq; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE parameter_data_seq FROM PUBLIC;
GRANT SELECT ON TABLE parameter_data_seq TO eblauser;


--
-- TOC entry 44 (OID 129054)
-- Name: parameter_data; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE parameter_data (
    parameter_id integer DEFAULT nextval('parameter_data_seq'::text) NOT NULL,
    description character varying(100),
    tmp_path character varying(50),
    seg_color_radius double precision DEFAULT 6.5 NOT NULL,
    seg_spatial_radius integer DEFAULT 7 NOT NULL,
    seg_min_region integer DEFAULT 20 NOT NULL,
    seg_speed_up_code smallint DEFAULT 0 NOT NULL,
    frame_prefix character varying(50),
    seg_prefix character varying(50),
    poly_prefix character varying(50),
    background_pixels double precision DEFAULT 20.0 NOT NULL,
    min_pixel_count integer DEFAULT 500 NOT NULL,
    min_frame_count integer DEFAULT 7 NOT NULL,
    reduce_color_code smallint DEFAULT 0 NOT NULL,
    notes character varying(255),
    seg_speed_up_factor double precision DEFAULT 0.5 NOT NULL
);


--
-- TOC entry 45 (OID 129054)
-- Name: parameter_data; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE parameter_data FROM PUBLIC;
GRANT SELECT ON TABLE parameter_data TO eblauser;


--
-- TOC entry 5 (OID 129066)
-- Name: experience_data_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE experience_data_seq
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;


--
-- TOC entry 7 (OID 129066)
-- Name: experience_data_seq; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE experience_data_seq FROM PUBLIC;
GRANT SELECT ON TABLE experience_data_seq TO eblauser;


--
-- TOC entry 46 (OID 129068)
-- Name: experience_data; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE experience_data (
    experience_id integer DEFAULT nextval('experience_data_seq'::text) NOT NULL,
    description character varying(50) NOT NULL,
    video_path character varying(100) NOT NULL,
    tmp_path character varying(50),
    experience_lexemes character varying(100),
    notes character varying(255)
);


--
-- TOC entry 47 (OID 129068)
-- Name: experience_data; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE experience_data FROM PUBLIC;
GRANT SELECT ON TABLE experience_data TO eblauser;


--
-- TOC entry 8 (OID 129071)
-- Name: attribute_list_data_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE attribute_list_data_seq
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;


--
-- TOC entry 10 (OID 129071)
-- Name: attribute_list_data_seq; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE attribute_list_data_seq FROM PUBLIC;
GRANT SELECT ON TABLE attribute_list_data_seq TO eblauser;


--
-- TOC entry 48 (OID 129073)
-- Name: attribute_list_data; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE attribute_list_data (
    attribute_list_id integer DEFAULT nextval('attribute_list_data_seq'::text) NOT NULL,
    description character varying(50) NOT NULL,
    include_code smallint DEFAULT 1 NOT NULL,
    type_code smallint DEFAULT 0 NOT NULL,
    class_name character varying(50),
    notes character varying(255)
);


--
-- TOC entry 49 (OID 129073)
-- Name: attribute_list_data; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE attribute_list_data FROM PUBLIC;
GRANT SELECT ON TABLE attribute_list_data TO eblauser;


--
-- TOC entry 11 (OID 129078)
-- Name: session_data_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE session_data_seq
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;


--
-- TOC entry 13 (OID 129078)
-- Name: session_data_seq; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE session_data_seq FROM PUBLIC;
GRANT SELECT,UPDATE ON TABLE session_data_seq TO eblauser;


--
-- TOC entry 50 (OID 129080)
-- Name: session_data; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE session_data (
    session_id integer DEFAULT nextval('session_data_seq'::text) NOT NULL,
    parameter_id integer,
    description character varying(100),
    session_start timestamp without time zone DEFAULT now() NOT NULL,
    session_stop timestamp without time zone,
    regen_int_images_code smallint DEFAULT 0 NOT NULL,
    log_to_file_code smallint DEFAULT 0 NOT NULL,
    randomize_exp_code smallint DEFAULT 0 NOT NULL,
    desc_to_generate integer DEFAULT 0 NOT NULL,
    min_sd_start integer DEFAULT 5 NOT NULL,
    min_sd_stop integer DEFAULT 5 NOT NULL,
    min_sd_step integer DEFAULT 5 NOT NULL,
    loop_count integer DEFAULT 1 NOT NULL,
    fixed_sd_code smallint DEFAULT 0 NOT NULL,
    display_movie_code smallint DEFAULT 0 NOT NULL,
    display_text_code smallint DEFAULT 0 NOT NULL,
    case_sensitive_code smallint DEFAULT 0 NOT NULL,
    notes character varying(255),
    session_ip character varying(100)
);


--
-- TOC entry 51 (OID 129080)
-- Name: session_data; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE session_data FROM PUBLIC;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE session_data TO eblauser;


--
-- TOC entry 14 (OID 129096)
-- Name: parameter_experience_data_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE parameter_experience_data_seq
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;


--
-- TOC entry 16 (OID 129096)
-- Name: parameter_experience_data_seq; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE parameter_experience_data_seq FROM PUBLIC;
GRANT SELECT ON TABLE parameter_experience_data_seq TO eblauser;


--
-- TOC entry 52 (OID 129098)
-- Name: parameter_experience_data; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE parameter_experience_data (
    parameter_experience_id integer DEFAULT nextval('parameter_experience_data_seq'::text) NOT NULL,
    parameter_id integer,
    experience_id integer,
    calc_status_code smallint DEFAULT 0 NOT NULL,
    calc_timestamp timestamp without time zone DEFAULT now() NOT NULL
);


--
-- TOC entry 53 (OID 129098)
-- Name: parameter_experience_data; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE parameter_experience_data FROM PUBLIC;
GRANT SELECT ON TABLE parameter_experience_data TO eblauser;


--
-- TOC entry 17 (OID 129103)
-- Name: frame_analysis_data_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE frame_analysis_data_seq
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;


--
-- TOC entry 19 (OID 129103)
-- Name: frame_analysis_data_seq; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE frame_analysis_data_seq FROM PUBLIC;
GRANT SELECT,UPDATE ON TABLE frame_analysis_data_seq TO eblauser;


--
-- TOC entry 54 (OID 129105)
-- Name: frame_analysis_data; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE frame_analysis_data (
    frame_analysis_id integer DEFAULT nextval('frame_analysis_data_seq'::text) NOT NULL,
    parameter_experience_id integer,
    frame_number integer DEFAULT 0 NOT NULL,
    object_number integer DEFAULT 0 NOT NULL,
    polygon_point_count integer DEFAULT 0 NOT NULL,
    polygon_point_list text NOT NULL,
    rgb_color integer DEFAULT 0 NOT NULL,
    bound_rect_points character varying(50) NOT NULL,
    centroid_x integer DEFAULT 0 NOT NULL,
    centroid_y integer DEFAULT 0 NOT NULL,
    area double precision DEFAULT 0 NOT NULL
);


--
-- TOC entry 55 (OID 129105)
-- Name: frame_analysis_data; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE frame_analysis_data FROM PUBLIC;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE frame_analysis_data TO eblauser;


--
-- TOC entry 20 (OID 129118)
-- Name: run_data_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE run_data_seq
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;


--
-- TOC entry 22 (OID 129118)
-- Name: run_data_seq; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE run_data_seq FROM PUBLIC;
GRANT SELECT,UPDATE ON TABLE run_data_seq TO eblauser;


--
-- TOC entry 56 (OID 129120)
-- Name: run_data; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE run_data (
    run_id integer DEFAULT nextval('run_data_seq'::text) NOT NULL,
    session_id integer,
    run_index integer DEFAULT 0 NOT NULL,
    run_start timestamp without time zone DEFAULT now() NOT NULL,
    run_stop timestamp without time zone,
    min_sd integer DEFAULT 0 NOT NULL
);


--
-- TOC entry 57 (OID 129120)
-- Name: run_data; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE run_data FROM PUBLIC;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE run_data TO eblauser;


--
-- TOC entry 23 (OID 129126)
-- Name: entity_data_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE entity_data_seq
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;


--
-- TOC entry 25 (OID 129126)
-- Name: entity_data_seq; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE entity_data_seq FROM PUBLIC;
GRANT SELECT,UPDATE ON TABLE entity_data_seq TO eblauser;


--
-- TOC entry 58 (OID 129128)
-- Name: entity_data; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE entity_data (
    entity_id integer DEFAULT nextval('entity_data_seq'::text) NOT NULL,
    run_id integer,
    occurance_count integer DEFAULT 1 NOT NULL
);


--
-- TOC entry 59 (OID 129128)
-- Name: entity_data; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE entity_data FROM PUBLIC;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE entity_data TO eblauser;


--
-- TOC entry 26 (OID 129132)
-- Name: lexeme_data_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE lexeme_data_seq
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;


--
-- TOC entry 28 (OID 129132)
-- Name: lexeme_data_seq; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE lexeme_data_seq FROM PUBLIC;
GRANT SELECT,UPDATE ON TABLE lexeme_data_seq TO eblauser;


--
-- TOC entry 60 (OID 129134)
-- Name: lexeme_data; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE lexeme_data (
    lexeme_id integer DEFAULT nextval('lexeme_data_seq'::text) NOT NULL,
    run_id integer,
    lexeme character varying(50) NOT NULL,
    occurance_count integer DEFAULT 1 NOT NULL
);


--
-- TOC entry 61 (OID 129134)
-- Name: lexeme_data; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE lexeme_data FROM PUBLIC;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE lexeme_data TO eblauser;


--
-- TOC entry 29 (OID 129138)
-- Name: experience_run_data_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE experience_run_data_seq
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;


--
-- TOC entry 31 (OID 129138)
-- Name: experience_run_data_seq; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE experience_run_data_seq FROM PUBLIC;
GRANT SELECT,UPDATE ON TABLE experience_run_data_seq TO eblauser;


--
-- TOC entry 62 (OID 129140)
-- Name: experience_run_data; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE experience_run_data (
    experience_run_id integer DEFAULT nextval('experience_run_data_seq'::text) NOT NULL,
    experience_id integer,
    run_id integer,
    experience_index integer DEFAULT 0 NOT NULL,
    experience_description character varying(100)
);


--
-- TOC entry 63 (OID 129140)
-- Name: experience_run_data; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE experience_run_data FROM PUBLIC;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE experience_run_data TO eblauser;


--
-- TOC entry 32 (OID 129144)
-- Name: entity_lexeme_data_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE entity_lexeme_data_seq
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;


--
-- TOC entry 34 (OID 129144)
-- Name: entity_lexeme_data_seq; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE entity_lexeme_data_seq FROM PUBLIC;
GRANT SELECT,UPDATE ON TABLE entity_lexeme_data_seq TO eblauser;


--
-- TOC entry 64 (OID 129146)
-- Name: entity_lexeme_data; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE entity_lexeme_data (
    entity_lexeme_id integer DEFAULT nextval('entity_lexeme_data_seq'::text) NOT NULL,
    entity_id integer,
    lexeme_id integer,
    occurance_count integer DEFAULT 1 NOT NULL
);


--
-- TOC entry 65 (OID 129146)
-- Name: entity_lexeme_data; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE entity_lexeme_data FROM PUBLIC;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE entity_lexeme_data TO eblauser;


--
-- TOC entry 35 (OID 129150)
-- Name: experience_entity_data_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE experience_entity_data_seq
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;


--
-- TOC entry 37 (OID 129150)
-- Name: experience_entity_data_seq; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE experience_entity_data_seq FROM PUBLIC;
GRANT SELECT,UPDATE ON TABLE experience_entity_data_seq TO eblauser;


--
-- TOC entry 66 (OID 129152)
-- Name: experience_entity_data; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE experience_entity_data (
    experience_entity_id integer DEFAULT nextval('experience_entity_data_seq'::text) NOT NULL,
    experience_id integer,
    run_id integer,
    entity_id integer,
    resolution_code smallint DEFAULT 0 NOT NULL
);


--
-- TOC entry 67 (OID 129152)
-- Name: experience_entity_data; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE experience_entity_data FROM PUBLIC;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE experience_entity_data TO eblauser;


--
-- TOC entry 38 (OID 129156)
-- Name: experience_lexeme_data_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE experience_lexeme_data_seq
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;


--
-- TOC entry 40 (OID 129156)
-- Name: experience_lexeme_data_seq; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE experience_lexeme_data_seq FROM PUBLIC;
GRANT SELECT,UPDATE ON TABLE experience_lexeme_data_seq TO eblauser;


--
-- TOC entry 68 (OID 129158)
-- Name: experience_lexeme_data; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE experience_lexeme_data (
    experience_lexeme_id integer DEFAULT nextval('experience_lexeme_data_seq'::text) NOT NULL,
    experience_id integer,
    run_id integer,
    lexeme_id integer,
    resolution_code smallint DEFAULT 0 NOT NULL,
    resolution_index integer DEFAULT 0 NOT NULL
);


--
-- TOC entry 69 (OID 129158)
-- Name: experience_lexeme_data; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE experience_lexeme_data FROM PUBLIC;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE experience_lexeme_data TO eblauser;


--
-- TOC entry 41 (OID 129163)
-- Name: attribute_value_data_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE attribute_value_data_seq
    START 1
    INCREMENT 1
    MAXVALUE 9223372036854775807
    MINVALUE 1
    CACHE 1;


--
-- TOC entry 43 (OID 129163)
-- Name: attribute_value_data_seq; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE attribute_value_data_seq FROM PUBLIC;
GRANT SELECT,UPDATE ON TABLE attribute_value_data_seq TO eblauser;


--
-- TOC entry 70 (OID 129165)
-- Name: attribute_value_data; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE attribute_value_data (
    attribute_value_id integer DEFAULT nextval('attribute_value_data_seq'::text) NOT NULL,
    attribute_list_id integer,
    run_id integer,
    entity_id integer,
    avg_value double precision DEFAULT 0 NOT NULL,
    std_deviation double precision DEFAULT 0 NOT NULL
);


--
-- TOC entry 71 (OID 129165)
-- Name: attribute_value_data; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE attribute_value_data FROM PUBLIC;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE attribute_value_data TO eblauser;


--
-- Data for TOC entry 109 (OID 129054)
-- Name: parameter_data; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY parameter_data (parameter_id, description, tmp_path, seg_color_radius, seg_spatial_radius, seg_min_region, seg_speed_up_code, frame_prefix, seg_prefix, poly_prefix, background_pixels, min_pixel_count, min_frame_count, reduce_color_code, notes, seg_speed_up_factor) FROM stdin;
9	Animations	./images/animations/	6.5	7	20	2	/frame	/seg	/poly	20	500	7	0	All eight animations.	1
13	Videos-Best (Used for Descriptions)	./images/videos-best/	13	7	500	1	/frame	/seg	/poly	20	500	7	0	167 of 319 videos used to evaluate description performance.	0.5
11	Videos-OK (Used for Acquisition)	./images/videos-ok/	13	7	500	1	/frame	/seg	/poly	20	500	7	0	226 of 319 videos used to evaluate acquisition performance.	0.5
\.


--
-- Data for TOC entry 110 (OID 129068)
-- Name: experience_data; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY experience_data (experience_id, description, video_path, tmp_path, experience_lexemes, notes) FROM stdin;
312	vase_20020809_down1L	./experiences/vase_20020809_down1L.avi	vase_20020809_down1L	hand putdown vase	3;split
313	vase_20020809_down1R	./experiences/vase_20020809_down1R.avi	vase_20020809_down1R	hand putdown vase	2;
314	vase_20020809_down2L	./experiences/vase_20020809_down2L.avi	vase_20020809_down2L	hand putdown vase	4;
315	vase_20020809_down2R	./experiences/vase_20020809_down2R.avi	vase_20020809_down2R	hand putdown vase	2;
316	vase_20020809_push1L	./experiences/vase_20020809_push1L.avi	vase_20020809_push1L	hand push vase	2;
317	vase_20020809_push1R	./experiences/vase_20020809_push1R.avi	vase_20020809_push1R	hand push vase	3;split
325	vase_20020809_up1R	./experiences/vase_20020809_up1R.avi	vase_20020809_up1R	hand pickup vase	2;
326	vase_20020809_up2L	./experiences/vase_20020809_up2L.avi	vase_20020809_up2L	hand pickup vase	2;
327	vase_20020809_up2R	./experiences/vase_20020809_up2R.avi	vase_20020809_up2R	hand pickup vase	2;
4	ani_ball_touch1	./experiences/ball_touch1.avi	ball_touch1	hand touch ball	5;animation
6	ani_cube_down1	./experiences/cube_down1.avi	cube_down1	hand putdown cube	5;animation
5	ani_cube_up1	./experiences/cube_up1.avi	cube_up1	hand pickup cube	5;animation
58	bluebowl_20020809_up1L	./experiences/bluebowl_20020809_up1L.avi	bluebowl_20020809_up1L	hand pickup bowl	3;drop
59	bluebowl_20020809_up1R	./experiences/bluebowl_20020809_up1R.avi	bluebowl_20020809_up1R	hand pickup bowl	2;
1	ani_ball_up1	./experiences/ball_up1.avi	ball_up1	hand pickup ball	5;animation
8	ani_cube_touch1	./experiences/cube_touch1.avi	cube_touch1	hand touch cube	5;animation
60	bluebowl_20020809_up2L	./experiences/bluebowl_20020809_up2L.avi	bluebowl_20020809_up2L	hand pickup bowl	3;drop
266	greenring_20020809_down2L	./experiences/greenring_20020809_down2L.avi	greenring_20020809_down2L	hand putdown ring	4;drop
267	greenring_20020809_down2R	./experiences/greenring_20020809_down2R.avi	greenring_20020809_down2R	hand putdown ring	3;drop
268	greenring_20020809_drop1L	./experiences/greenring_20020809_drop1L.avi	greenring_20020809_drop1L	hand drop ring	4;drop
269	greenring_20020809_drop1R	./experiences/greenring_20020809_drop1R.avi	greenring_20020809_drop1R	hand drop ring	4;drop
270	greenring_20020809_drop2L	./experiences/greenring_20020809_drop2L.avi	greenring_20020809_drop2L	hand drop ring	4;drop
271	greenring_20020809_drop2R	./experiences/greenring_20020809_drop2R.avi	greenring_20020809_drop2R	hand drop ring	3;drop
272	greenring_20020809_drop3L	./experiences/greenring_20020809_drop3L.avi	greenring_20020809_drop3L	hand drop ring	4;drop
273	greenring_20020809_roll1L	./experiences/greenring_20020809_roll1L.avi	greenring_20020809_roll1L	hand roll ring	4;drop
274	greenring_20020809_roll1R	./experiences/greenring_20020809_roll1R.avi	greenring_20020809_roll1R	hand roll ring	2;
275	greenring_20020809_roll2L	./experiences/greenring_20020809_roll2L.avi	greenring_20020809_roll2L	hand roll ring	4;
276	greenring_20020809_roll2R	./experiences/greenring_20020809_roll2R.avi	greenring_20020809_roll2R	hand roll ring	3;drop
277	greenring_20020809_touch1L	./experiences/greenring_20020809_touch1L.avi	greenring_20020809_touch1L	hand touch ring	4;drop
278	greenring_20020809_touch1R	./experiences/greenring_20020809_touch1R.avi	greenring_20020809_touch1R	hand touch ring	4;drop
279	greenring_20020809_touch2L	./experiences/greenring_20020809_touch2L.avi	greenring_20020809_touch2L	hand touch ring	4;drop
280	greenring_20020809_touch2R	./experiences/greenring_20020809_touch2R.avi	greenring_20020809_touch2R	hand touch ring	3;drop
281	greenring_20020809_up1L	./experiences/greenring_20020809_up1L.avi	greenring_20020809_up1L	hand pickup ring	3;drop
282	greenring_20020809_up1R	./experiences/greenring_20020809_up1R.avi	greenring_20020809_up1R	hand pickup ring	3;drop
283	greenring_20020809_up2L	./experiences/greenring_20020809_up2L.avi	greenring_20020809_up2L	hand pickup ring	4;drop
284	greenring_20020809_up2R	./experiences/greenring_20020809_up2R.avi	greenring_20020809_up2R	hand pickup ring	4;drop
285	orangecup_20020809_down1L	./experiences/orangecup_20020809_down1L.avi	orangecup_20020809_down1L	hand putdown cup	2;
286	orangecup_20020809_down1R	./experiences/orangecup_20020809_down1R.avi	orangecup_20020809_down1R	hand putdown cup	3;shrunk
287	orangecup_20020809_down2R	./experiences/orangecup_20020809_down2R.avi	orangecup_20020809_down2R	hand putdown cup	4;shrunk
288	orangecup_20020809_pull1L	./experiences/orangecup_20020809_pull1L.avi	orangecup_20020809_pull1L	hand pull cup	3;drop
289	orangecup_20020809_pull1R	./experiences/orangecup_20020809_pull1R.avi	orangecup_20020809_pull1R	hand pull cup	3;drop
290	orangecup_20020809_pull2L	./experiences/orangecup_20020809_pull2L.avi	orangecup_20020809_pull2L	hand pull cup	4;drop
291	orangecup_20020809_pull2R	./experiences/orangecup_20020809_pull2R.avi	orangecup_20020809_pull2R	hand pull cup	3;drop
292	orangecup_20020809_push1L	./experiences/orangecup_20020809_push1L.avi	orangecup_20020809_push1L	hand push cup	3;drop
293	orangecup_20020809_push1R	./experiences/orangecup_20020809_push1R.avi	orangecup_20020809_push1R	hand push cup	4;drop
294	orangecup_20020809_push2L	./experiences/orangecup_20020809_push2L.avi	orangecup_20020809_push2L	hand push cup	4;drop
295	orangecup_20020809_push2R	./experiences/orangecup_20020809_push2R.avi	orangecup_20020809_push2R	hand push cup	4;drop
296	orangecup_20020809_tip1L	./experiences/orangecup_20020809_tip1L.avi	orangecup_20020809_tip1L	hand tipover cup	3;split
297	orangecup_20020809_tip1R	./experiences/orangecup_20020809_tip1R.avi	orangecup_20020809_tip1R	hand tipover cup	2;
298	orangecup_20020809_tip2L	./experiences/orangecup_20020809_tip2L.avi	orangecup_20020809_tip2L	hand tipover cup	3;split
299	orangecup_20020809_tip2R	./experiences/orangecup_20020809_tip2R.avi	orangecup_20020809_tip2R	hand tipover cup	3;split
300	orangecup_20020809_touch1L	./experiences/orangecup_20020809_touch1L.avi	orangecup_20020809_touch1L	hand touch cup	2;
301	orangecup_20020809_touch1R	./experiences/orangecup_20020809_touch1R.avi	orangecup_20020809_touch1R	hand touch cup	2;
302	orangecup_20020809_touch2L	./experiences/orangecup_20020809_touch2L.avi	orangecup_20020809_touch2L	hand touch cup	2;
303	orangecup_20020809_touch2R	./experiences/orangecup_20020809_touch2R.avi	orangecup_20020809_touch2R	hand touch cup	2;
304	orangecup_20020809_up1L	./experiences/orangecup_20020809_up1L.avi	orangecup_20020809_up1L	hand pickup cup	2;
305	orangecup_20020809_up1R	./experiences/orangecup_20020809_up1R.avi	orangecup_20020809_up1R	hand pickup cup	2;
306	orangecup_20020809_up2L	./experiences/orangecup_20020809_up2L.avi	orangecup_20020809_up2L	hand pickup cup	2;
307	orangecup_20020809_up2R	./experiences/orangecup_20020809_up2R.avi	orangecup_20020809_up2R	hand pickup cup	2;
308	rings_20020619_stack1R	./experiences/rings_20020619_stack1R.avi	rings_20020619_stack1R	hand stack rings	4;drop
309	rings_20020619_unstack1L	./experiences/rings_20020619_unstack1L.avi	rings_20020619_unstack1L	hand unstack rings	4;drop
310	rings_20020619_unstack1R	./experiences/rings_20020619_unstack1R.avi	rings_20020619_unstack1R	hand unstack rings	4;drop
311	rings_20020619_unstack2R	./experiences/rings_20020619_unstack2R.avi	rings_20020619_unstack2R	hand unstack rings	4;drop
220	greenbowl_20020809_drop2R	./experiences/greenbowl_20020809_drop2R.avi	greenbowl_20020809_drop2R	hand drop bowl	4;
221	greenbowl_20020809_pull1L	./experiences/greenbowl_20020809_pull1L.avi	greenbowl_20020809_pull1L	hand pull bowl	2;
222	greenbowl_20020809_pull1R	./experiences/greenbowl_20020809_pull1R.avi	greenbowl_20020809_pull1R	hand pull bowl	2;
223	greenbowl_20020809_pull2L	./experiences/greenbowl_20020809_pull2L.avi	greenbowl_20020809_pull2L	hand pull bowl	2;
224	greenbowl_20020809_pull2R	./experiences/greenbowl_20020809_pull2R.avi	greenbowl_20020809_pull2R	hand pull bowl	2;
225	greenbowl_20020809_push1L	./experiences/greenbowl_20020809_push1L.avi	greenbowl_20020809_push1L	hand push bowl	2;
226	greenbowl_20020809_push1R	./experiences/greenbowl_20020809_push1R.avi	greenbowl_20020809_push1R	hand push bowl	4;drop
227	greenbowl_20020809_push2L	./experiences/greenbowl_20020809_push2L.avi	greenbowl_20020809_push2L	hand push bowl	4;drop
228	greenbowl_20020809_push2R	./experiences/greenbowl_20020809_push2R.avi	greenbowl_20020809_push2R	hand push bowl	3;drop
229	greenbowl_20020809_touch1L	./experiences/greenbowl_20020809_touch1L.avi	greenbowl_20020809_touch1L	hand touch ring	2;
230	greenbowl_20020809_touch1R	./experiences/greenbowl_20020809_touch1R.avi	greenbowl_20020809_touch1R	hand touch ring	2;
231	greenbowl_20020809_touch2L	./experiences/greenbowl_20020809_touch2L.avi	greenbowl_20020809_touch2L	hand touch ring	2;
232	greenbowl_20020809_touch2R	./experiences/greenbowl_20020809_touch2R.avi	greenbowl_20020809_touch2R	hand touch ring	2;
233	greenbowl_20020809_up1L	./experiences/greenbowl_20020809_up1L.avi	greenbowl_20020809_up1L	hand pickup bowl	3;drop
234	greenbowl_20020809_up1R	./experiences/greenbowl_20020809_up1R.avi	greenbowl_20020809_up1R	hand pickup bowl	2;
235	greenring_20020619_down1L	./experiences/greenring_20020619_down1L.avi	greenring_20020619_down1L	hand putdown ring	4;
236	greenring_20020619_down1R	./experiences/greenring_20020619_down1R.avi	greenring_20020619_down1R	hand putdown ring	4;drop
237	greenring_20020619_down2L	./experiences/greenring_20020619_down2L.avi	greenring_20020619_down2L	hand putdown ring	4;
238	greenring_20020619_down2R	./experiences/greenring_20020619_down2R.avi	greenring_20020619_down2R	hand putdown ring	4;drop
239	greenring_20020619_drop1R	./experiences/greenring_20020619_drop1R.avi	greenring_20020619_drop1R	hand drop ring	3;drop
240	greenring_20020619_drop2R	./experiences/greenring_20020619_drop2R.avi	greenring_20020619_drop2R	hand drop ring	4;drop
241	greenring_20020619_drop3R	./experiences/greenring_20020619_drop3R.avi	greenring_20020619_drop3R	hand drop ring	4;drop
242	greenring_20020619_drop4R	./experiences/greenring_20020619_drop4R.avi	greenring_20020619_drop4R	hand drop ring	4;
243	greenring_20020619_pull1L	./experiences/greenring_20020619_pull1L.avi	greenring_20020619_pull1L	hand pull ring	2;
244	greenring_20020619_pull1R	./experiences/greenring_20020619_pull1R.avi	greenring_20020619_pull1R	hand pull ring	3;drop
245	greenring_20020619_slide1L	./experiences/greenring_20020619_slide1L.avi	greenring_20020619_slide1L	hand slide ring	2;
246	greenring_20020619_slide1R	./experiences/greenring_20020619_slide1R.avi	greenring_20020619_slide1R	hand slide ring	3;drop
247	greenring_20020619_tilt1L	./experiences/greenring_20020619_tilt1L.avi	greenring_20020619_tilt1L	hand tilt ring	2;
248	greenring_20020619_tilt1R	./experiences/greenring_20020619_tilt1R.avi	greenring_20020619_tilt1R	hand tilt ring	2;
249	greenring_20020619_tilt2L	./experiences/greenring_20020619_tilt2L.avi	greenring_20020619_tilt2L	hand tilt ring	2;
250	greenring_20020619_tilt2R	./experiences/greenring_20020619_tilt2R.avi	greenring_20020619_tilt2R	hand tilt ring	4;drop
251	greenring_20020619_tipover1L	./experiences/greenring_20020619_tipover1L.avi	greenring_20020619_tipover1L	hand tipover ring	2;
252	greenring_20020619_tipover1R	./experiences/greenring_20020619_tipover1R.avi	greenring_20020619_tipover1R	hand tipover ring	4;drop
253	greenring_20020619_tipover2L	./experiences/greenring_20020619_tipover2L.avi	greenring_20020619_tipover2L	hand tipover ring	2;
254	greenring_20020619_tipover2R	./experiences/greenring_20020619_tipover2R.avi	greenring_20020619_tipover2R	hand tipover ring	4;drop
255	greenring_20020619_touch1L	./experiences/greenring_20020619_touch1L.avi	greenring_20020619_touch1L	hand touch ring	2;
256	greenring_20020619_touch1R	./experiences/greenring_20020619_touch1R.avi	greenring_20020619_touch1R	hand touch ring	2;
257	greenring_20020619_touch2L	./experiences/greenring_20020619_touch2L.avi	greenring_20020619_touch2L	hand touch ring	2;
258	greenring_20020619_touch2R	./experiences/greenring_20020619_touch2R.avi	greenring_20020619_touch2R	hand touch ring	2;
259	greenring_20020619_up1L	./experiences/greenring_20020619_up1L.avi	greenring_20020619_up1L	hand pickup ring	2;
260	greenring_20020619_up1R	./experiences/greenring_20020619_up1R.avi	greenring_20020619_up1R	hand pickup ring	4;drop
261	greenring_20020619_up2L	./experiences/greenring_20020619_up2L.avi	greenring_20020619_up2L	hand pickup ring	4;
262	greenring_20020619_up2R	./experiences/greenring_20020619_up2R.avi	greenring_20020619_up2R	hand pickup ring	4;drop
263	greenring_20020619_up3L	./experiences/greenring_20020619_up3L.avi	greenring_20020619_up3L	hand pickup ring	4;
264	greenring_20020809_down1L	./experiences/greenring_20020809_down1L.avi	greenring_20020809_down1L	hand putdown ring	4;drop
265	greenring_20020809_down1R	./experiences/greenring_20020809_down1R.avi	greenring_20020809_down1R	hand putdown ring	3;drop
172	box_20020809_up1L	./experiences/box_20020809_up1L.avi	box_20020809_up1L	hand pickup box	2;
173	box_20020809_up1R	./experiences/box_20020809_up1R.avi	box_20020809_up1R	hand pickup box	2;
174	box_20020809_up2L	./experiences/box_20020809_up2L.avi	box_20020809_up2L	hand pickup box	2;
175	box_20020809_up2R	./experiences/box_20020809_up2R.avi	box_20020809_up2R	hand pickup box	2;
176	cup_20020619_down1L	./experiences/cup_20020619_down1L.avi	cup_20020619_down1L	hand putdown cup	2;
177	cup_20020619_down1R	./experiences/cup_20020619_down1R.avi	cup_20020619_down1R	hand putdown cup	4;drop
178	cup_20020619_down2L	./experiences/cup_20020619_down2L.avi	cup_20020619_down2L	hand putdown cup	2;
179	cup_20020619_down2R	./experiences/cup_20020619_down2R.avi	cup_20020619_down2R	hand putdown cup	4;drop
180	cup_20020619_pull1L	./experiences/cup_20020619_pull1L.avi	cup_20020619_pull1L	hand pull cup	2;
181	cup_20020619_pull1R	./experiences/cup_20020619_pull1R.avi	cup_20020619_pull1R	hand pull cup	4;drop
182	cup_20020619_slide1L	./experiences/cup_20020619_slide1L.avi	cup_20020619_slide1L	hand slide cup	3;drop
183	cup_20020619_slide1R	./experiences/cup_20020619_slide1R.avi	cup_20020619_slide1R	hand slide cup	3;drop
184	cup_20020619_slide2L	./experiences/cup_20020619_slide2L.avi	cup_20020619_slide2L	hand slide cup	2;
185	cup_20020619_tipover1L	./experiences/cup_20020619_tipover1L.avi	cup_20020619_tipover1L	hand tipover cup	2;
186	cup_20020619_tipover1R	./experiences/cup_20020619_tipover1R.avi	cup_20020619_tipover1R	hand tipover cup	2;
187	cup_20020619_tipover2L	./experiences/cup_20020619_tipover2L.avi	cup_20020619_tipover2L	hand tipover cup	2;
188	cup_20020619_tipover2R	./experiences/cup_20020619_tipover2R.avi	cup_20020619_tipover2R	hand tipover cup	2;
189	cup_20020619_touch1L	./experiences/cup_20020619_touch1L.avi	cup_20020619_touch1L	hand touch cup	2;
190	cup_20020619_touch1R	./experiences/cup_20020619_touch1R.avi	cup_20020619_touch1R	hand touch cup	2;
191	cup_20020619_touch2L	./experiences/cup_20020619_touch2L.avi	cup_20020619_touch2L	hand touch cup	2;
192	cup_20020619_touch2R	./experiences/cup_20020619_touch2R.avi	cup_20020619_touch2R	hand touch cup	2;
193	cup_20020619_up1L	./experiences/cup_20020619_up1L.avi	cup_20020619_up1L	hand pickup cup	2;
194	cup_20020619_up1R	./experiences/cup_20020619_up1R.avi	cup_20020619_up1R	hand pickup cup	2;
195	cup_20020619_up2L	./experiences/cup_20020619_up2L.avi	cup_20020619_up2L	hand pickup cup	2;
196	cup_20020619_up2R	./experiences/cup_20020619_up2R.avi	cup_20020619_up2R	hand pickup cup	3;drop
197	garfield_20020809_up1L	./experiences/garfield_20020809_up1L.avi	garfield_20020809_up1L	hand pickup garfield	3;split
198	garfield_20020809_down1L	./experiences/garfield_20020809_down1L.avi	garfield_20020809_down1L	hand putdown garfield	4;split
199	garfield_20020809_down1R	./experiences/garfield_20020809_down1R.avi	garfield_20020809_down1R	hand putdown garfield	4;split
200	garfield_20020809_down2L	./experiences/garfield_20020809_down2L.avi	garfield_20020809_down2L	hand putdown garfield	3;drop and split
201	garfield_20020809_down2R	./experiences/garfield_20020809_down2R.avi	garfield_20020809_down2R	hand putdown garfield	3;split
202	garfield_20020809_drop1L	./experiences/garfield_20020809_drop1L.avi	garfield_20020809_drop1L	hand drop garfield	3;split
203	garfield_20020809_drop1R	./experiences/garfield_20020809_drop1R.avi	garfield_20020809_drop1R	hand drop garfield	3;split
204	garfield_20020809_drop2L	./experiences/garfield_20020809_drop2L.avi	garfield_20020809_drop2L	hand drop garfield	3;split
205	garfield_20020809_drop2R	./experiences/garfield_20020809_drop2R.avi	garfield_20020809_drop2R	hand drop garfield	4;split
206	garfield_20020809_touch1L	./experiences/garfield_20020809_touch1L.avi	garfield_20020809_touch1L	hand touch garfield	3;split
207	garfield_20020809_touch1R	./experiences/garfield_20020809_touch1R.avi	garfield_20020809_touch1R	hand touch garfield	3;drop and split
208	garfield_20020809_touch2L	./experiences/garfield_20020809_touch2L.avi	garfield_20020809_touch2L	hand touch garfield	3;split
209	garfield_20020809_touch2R	./experiences/garfield_20020809_touch2R.avi	garfield_20020809_touch2R	hand touch garfield	3;split
210	garfield_20020809_up1R	./experiences/garfield_20020809_up1R.avi	garfield_20020809_up1R	hand pickup garfield	3;split
211	garfield_20020809_up2L	./experiences/garfield_20020809_up2L.avi	garfield_20020809_up2L	hand pickup garfield	3;drop and split
212	garfield_20020809_up2R	./experiences/garfield_20020809_up2R.avi	garfield_20020809_up2R	hand pickup garfield	3;split
213	greenbowl_20020809_down1L	./experiences/greenbowl_20020809_down1L.avi	greenbowl_20020809_down1L	hand putdown bowl	4;drop
214	greenbowl_20020809_down1R	./experiences/greenbowl_20020809_down1R.avi	greenbowl_20020809_down1R	hand putdown bowl	2;
215	greenbowl_20020809_down2L	./experiences/greenbowl_20020809_down2L.avi	greenbowl_20020809_down2L	hand putdown bowl	3;drop
216	greenbowl_20020809_down2R	./experiences/greenbowl_20020809_down2R.avi	greenbowl_20020809_down2R	hand putdown bowl	2;
217	greenbowl_20020809_drop1L	./experiences/greenbowl_20020809_drop1L.avi	greenbowl_20020809_drop1L	hand drop bowl	2;
218	greenbowl_20020809_drop1R	./experiences/greenbowl_20020809_drop1R.avi	greenbowl_20020809_drop1R	hand drop bowl	2;
219	greenbowl_20020809_drop2L	./experiences/greenbowl_20020809_drop2L.avi	greenbowl_20020809_drop2L	hand drop bowl	2;
121	book_20020809_slide1R	./experiences/book_20020809_slide1R.avi	book_20020809_slide1R	hand slide book	4;split
122	book_20020809_slide2L	./experiences/book_20020809_slide2L.avi	book_20020809_slide2L	hand slide book	3;split
123	book_20020809_slide2R	./experiences/book_20020809_slide2R.avi	book_20020809_slide2R	hand slide book	3;split
124	book_20020809_tilt1L	./experiences/book_20020809_tilt1L.avi	book_20020809_tilt1L	hand tipover book	4;split
125	book_20020809_tilt1R	./experiences/book_20020809_tilt1R.avi	book_20020809_tilt1R	hand tipover book	4;split
126	book_20020809_tilt2L	./experiences/book_20020809_tilt2L.avi	book_20020809_tilt2L	hand tipover book	4;split
127	book_20020809_tilt2R	./experiences/book_20020809_tilt2R.avi	book_20020809_tilt2R	hand tipover book	4;split
128	book_20020809_touch1L	./experiences/book_20020809_touch1L.avi	book_20020809_touch1L	hand touch book	4;
129	book_20020809_touch1R	./experiences/book_20020809_touch1R.avi	book_20020809_touch1R	hand touch book	3;split
130	book_20020809_touch2L	./experiences/book_20020809_touch2L.avi	book_20020809_touch2L	hand touch book	4;
131	book_20020809_touch2R	./experiences/book_20020809_touch2R.avi	book_20020809_touch2R	hand touch book	2;
132	book_20020809_up1L	./experiences/book_20020809_up1L.avi	book_20020809_up1L	hand pickup book	2;
133	book_20020809_up1R	./experiences/book_20020809_up1R.avi	book_20020809_up1R	hand pickup book	2;
134	book_20020809_up2L	./experiences/book_20020809_up2L.avi	book_20020809_up2L	hand pickup book	2;
135	book_20020809_up2R	./experiences/book_20020809_up2R.avi	book_20020809_up2R	hand pickup book	2;
136	box_20020619_down1L	./experiences/box_20020619_down1L.avi	box_20020619_down1L	hand putdown box	2;
137	box_20020619_down1R	./experiences/box_20020619_down1R.avi	box_20020619_down1R	hand putdown box	3;merge
138	box_20020619_down2L	./experiences/box_20020619_down2L.avi	box_20020619_down2L	hand putdown box	4;merge
139	box_20020619_down2R	./experiences/box_20020619_down2R.avi	box_20020619_down2R	hand putdown box	3;merge
140	box_20020619_pull1L	./experiences/box_20020619_pull1L.avi	box_20020619_pull1L	hand pull box	2;
141	box_20020619_pull1R	./experiences/box_20020619_pull1R.avi	box_20020619_pull1R	hand pull box	3;drop
142	box_20020619_slide1L	./experiences/box_20020619_slide1L.avi	box_20020619_slide1L	hand slide box	2;
143	box_20020619_slide1R	./experiences/box_20020619_slide1R.avi	box_20020619_slide1R	hand slide box	3;drop
144	box_20020619_tipover1L	./experiences/box_20020619_tipover1L.avi	box_20020619_tipover1L	hand tipover box	2;
145	box_20020619_tipover1R	./experiences/box_20020619_tipover1R.avi	box_20020619_tipover1R	hand tipover box	2;
146	box_20020619_tipover2L	./experiences/box_20020619_tipover2L.avi	box_20020619_tipover2L	hand tipover box	2;
147	box_20020619_tipover2R	./experiences/box_20020619_tipover2R.avi	box_20020619_tipover2R	hand tipover box	2;
148	box_20020619_touch1L	./experiences/box_20020619_touch1L.avi	box_20020619_touch1L	hand touch box	2;
149	box_20020619_touch1R	./experiences/box_20020619_touch1R.avi	box_20020619_touch1R	hand touch box	2;
150	box_20020619_touch2L	./experiences/box_20020619_touch2L.avi	box_20020619_touch2L	hand touch box	2;
151	box_20020619_touch2R	./experiences/box_20020619_touch2R.avi	box_20020619_touch2R	hand touch box	2;
152	box_20020619_up1L	./experiences/box_20020619_up1L.avi	box_20020619_up1L	hand pickup box	2;
153	box_20020619_up1R	./experiences/box_20020619_up1R.avi	box_20020619_up1R	hand pickup box	3;drop
154	box_20020619_up2L	./experiences/box_20020619_up2L.avi	box_20020619_up2L	hand pickup box	4;merge
155	box_20020619_up3L	./experiences/box_20020619_up3L.avi	box_20020619_up3L	hand pickup box	3;merge
156	box_20020809_down1L	./experiences/box_20020809_down1L.avi	box_20020809_down1L	hand putdown box	2;
157	box_20020809_down1R	./experiences/box_20020809_down1R.avi	box_20020809_down1R	hand putdown box	2;
158	box_20020809_down2L	./experiences/box_20020809_down2L.avi	box_20020809_down2L	hand putdown box	2;
159	box_20020809_down2R	./experiences/box_20020809_down2R.avi	box_20020809_down2R	hand putdown box	2;
160	box_20020809_drop1L	./experiences/box_20020809_drop1L.avi	box_20020809_drop1L	hand drop box	2;
161	box_20020809_drop1R	./experiences/box_20020809_drop1R.avi	box_20020809_drop1R	hand drop box	4;
162	box_20020809_drop2L	./experiences/box_20020809_drop2L.avi	box_20020809_drop2L	hand drop box	2;
163	box_20020809_drop2R	./experiences/box_20020809_drop2R.avi	box_20020809_drop2R	hand drop box	2;
164	box_20020809_push1L	./experiences/box_20020809_push1L.avi	box_20020809_push1L	hand push box	2;
165	box_20020809_push1R	./experiences/box_20020809_push1R.avi	box_20020809_push1R	hand push box	2;
166	box_20020809_push2L	./experiences/box_20020809_push2L.avi	box_20020809_push2L	hand push box	4;
167	box_20020809_push2R	./experiences/box_20020809_push2R.avi	box_20020809_push2R	hand push box	2;
168	box_20020809_touch1L	./experiences/box_20020809_touch1L.avi	box_20020809_touch1L	hand touch box	2;
169	box_20020809_touch1R	./experiences/box_20020809_touch1R.avi	box_20020809_touch1R	hand touch box	2;
170	box_20020809_touch2L	./experiences/box_20020809_touch2L.avi	box_20020809_touch2L	hand touch box	2;
171	box_20020809_touch2R	./experiences/box_20020809_touch2R.avi	box_20020809_touch2R	hand touch box	2;
74	bluering_20020619_tilt1L	./experiences/bluering_20020619_tilt1L.avi	bluering_20020619_tilt1L	hand tilt ring	2;
75	bluering_20020619_tilt1R	./experiences/bluering_20020619_tilt1R.avi	bluering_20020619_tilt1R	hand tilt ring	2;
76	bluering_20020619_tilt2L	./experiences/bluering_20020619_tilt2L.avi	bluering_20020619_tilt2L	hand tilt ring	2;
77	bluering_20020619_tilt2R	./experiences/bluering_20020619_tilt2R.avi	bluering_20020619_tilt2R	hand tilt ring	2;
78	bluering_20020619_tilt3R	./experiences/bluering_20020619_tilt3R.avi	bluering_20020619_tilt3R	hand tilt ring	4;
79	bluering_20020619_tipover1L	./experiences/bluering_20020619_tipover1L.avi	bluering_20020619_tipover1L	hand tipover ring	2;
80	bluering_20020619_tipover1R	./experiences/bluering_20020619_tipover1R.avi	bluering_20020619_tipover1R	hand tipover ring	2;
81	bluering_20020619_tipover2L	./experiences/bluering_20020619_tipover2L.avi	bluering_20020619_tipover2L	hand tipover ring	2;
82	bluering_20020619_tipover2R	./experiences/bluering_20020619_tipover2R.avi	bluering_20020619_tipover2R	hand tipover ring	2;
83	bluering_20020619_touch1L	./experiences/bluering_20020619_touch1L.avi	bluering_20020619_touch1L	hand touch ring	2;
84	bluering_20020619_touch1R	./experiences/bluering_20020619_touch1R.avi	bluering_20020619_touch1R	hand touch ring	2;
85	bluering_20020619_touch2L	./experiences/bluering_20020619_touch2L.avi	bluering_20020619_touch2L	hand touch ring	2;
86	bluering_20020619_touch3L	./experiences/bluering_20020619_touch3L.avi	bluering_20020619_touch3L	hand touch ring	2;
87	bluering_20020619_up1L	./experiences/bluering_20020619_up1L.avi	bluering_20020619_up1L	hand pickup ring	4;
88	bluering_20020619_up1R	./experiences/bluering_20020619_up1R.avi	bluering_20020619_up1R	hand pickup ring	4;
89	bluering_20020619_up2L	./experiences/bluering_20020619_up2L.avi	bluering_20020619_up2L	hand pickup ring	4;
90	bluering_20020619_up3L	./experiences/bluering_20020619_up3L.avi	bluering_20020619_up3L	hand pickup ring	2;
91	bluering_20020809_down1L	./experiences/bluering_20020809_down1L.avi	bluering_20020809_down1L	hand putdown ring	4;drop
92	bluering_20020809_down1R	./experiences/bluering_20020809_down1R.avi	bluering_20020809_down1R	hand putdown ring	4;drop
93	bluering_20020809_down2L	./experiences/bluering_20020809_down2L.avi	bluering_20020809_down2L	hand putdown ring	4;drop
94	bluering_20020809_down2R	./experiences/bluering_20020809_down2R.avi	bluering_20020809_down2R	hand putdown ring	4;drop
95	bluering_20020809_drop1L	./experiences/bluering_20020809_drop1L.avi	bluering_20020809_drop1L	hand drop ring	4;drop
96	bluering_20020809_drop1R	./experiences/bluering_20020809_drop1R.avi	bluering_20020809_drop1R	hand drop ring	4;drop
97	bluering_20020809_drop2L	./experiences/bluering_20020809_drop2L.avi	bluering_20020809_drop2L	hand drop ring	4;drop
98	bluering_20020809_drop2R	./experiences/bluering_20020809_drop2R.avi	bluering_20020809_drop2R	hand drop ring	4;drop
99	bluering_20020809_roll1L	./experiences/bluering_20020809_roll1L.avi	bluering_20020809_roll1L	hand roll ring	4;
100	bluering_20020809_roll1R	./experiences/bluering_20020809_roll1R.avi	bluering_20020809_roll1R	hand roll ring	4;drop
101	bluering_20020809_roll2L	./experiences/bluering_20020809_roll2L.avi	bluering_20020809_roll2L	hand roll ring	4;
102	bluering_20020809_roll2R	./experiences/bluering_20020809_roll2R.avi	bluering_20020809_roll2R	hand roll ring	3;drop
103	bluering_20020809_rollchaseL	./experiences/bluering_20020809_rollchaseL.avi	bluering_20020809_rollchaseL	hand roll ring	2;
104	bluering_20020809_touch1L	./experiences/bluering_20020809_touch1L.avi	bluering_20020809_touch1L	hand touch ring	4;drop
105	bluering_20020809_touch1R	./experiences/bluering_20020809_touch1R.avi	bluering_20020809_touch1R	hand touch ring	3;drop
106	bluering_20020809_touch2L	./experiences/bluering_20020809_touch2L.avi	bluering_20020809_touch2L	hand touch ring	4;drop
107	bluering_20020809_touch2R	./experiences/bluering_20020809_touch2R.avi	bluering_20020809_touch2R	hand touch ring	3;drop
108	bluering_20020809_up1L	./experiences/bluering_20020809_up1L.avi	bluering_20020809_up1L	hand pickup ring	3;drop
109	bluering_20020809_up1R	./experiences/bluering_20020809_up1R.avi	bluering_20020809_up1R	hand pickup ring	3;drop
110	bluering_20020809_up2L	./experiences/bluering_20020809_up2L.avi	bluering_20020809_up2L	hand pickup ring	4;drop
111	bluering_20020809_up2R	./experiences/bluering_20020809_up2R.avi	bluering_20020809_up2R	hand pickup ring	4;drop
112	book_20020809_down1L	./experiences/book_20020809_down1L.avi	book_20020809_down1L	hand putdown book	2;
113	book_20020809_down1R	./experiences/book_20020809_down1R.avi	book_20020809_down1R	hand putdown book	2;
114	book_20020809_down2L	./experiences/book_20020809_down2L.avi	book_20020809_down2L	hand putdown book	2;
115	book_20020809_down2R	./experiences/book_20020809_down2R.avi	book_20020809_down2R	hand putdown book	2;
116	book_20020809_pull1L	./experiences/book_20020809_pull1L.avi	book_20020809_pull1L	hand pull book	3;split
117	book_20020809_pull1R	./experiences/book_20020809_pull1R.avi	book_20020809_pull1R	hand pull book	4;split
118	book_20020809_pull2L	./experiences/book_20020809_pull2L.avi	book_20020809_pull2L	hand pull book	4;split
119	book_20020809_pull2R	./experiences/book_20020809_pull2R.avi	book_20020809_pull2R	hand pull book	3;split
120	book_20020809_slide1L	./experiences/book_20020809_slide1L.avi	book_20020809_slide1L	hand slide book	3;split
25	ball_20020809_drop2L	./experiences/ball_20020809_drop2L.avi	ball_20020809_drop2L	hand drop ball	2;
26	ball_20020809_drop2R	./experiences/ball_20020809_drop2R.avi	ball_20020809_drop2R	hand drop ball	2;
27	ball_20020809_roll1L	./experiences/ball_20020809_roll1L.avi	ball_20020809_roll1L	hand roll ball	2;
28	ball_20020809_roll1R	./experiences/ball_20020809_roll1R.avi	ball_20020809_roll1R	hand roll ball	2;
29	ball_20020809_roll2L	./experiences/ball_20020809_roll2L.avi	ball_20020809_roll2L	hand roll ball	2;
30	ball_20020809_roll2R	./experiences/ball_20020809_roll2R.avi	ball_20020809_roll2R	hand roll ball	4;
31	ball_20020809_touch1L	./experiences/ball_20020809_touch1L.avi	ball_20020809_touch1L	hand touch ball	2;
32	ball_20020809_touch1R	./experiences/ball_20020809_touch1R.avi	ball_20020809_touch1R	hand touch ball	2;
33	ball_20020809_touch2L	./experiences/ball_20020809_touch2L.avi	ball_20020809_touch2L	hand touch ball	2;
34	ball_20020809_touch2R	./experiences/ball_20020809_touch2R.avi	ball_20020809_touch2R	hand touch ball	2;
35	ball_20020809_up1L	./experiences/ball_20020809_up1L.avi	ball_20020809_up1L	hand pickup ball	2;
36	ball_20020809_up1R	./experiences/ball_20020809_up1R.avi	ball_20020809_up1R	hand pickup ball	2;
37	ball_20020809_up2L	./experiences/ball_20020809_up2L.avi	ball_20020809_up2L	hand pickup ball	2;
38	ball_20020809_up2R	./experiences/ball_20020809_up2R.avi	ball_20020809_up2R	hand pickup ball	2;
39	bluebowl_20020809_down1L	./experiences/bluebowl_20020809_down1L.avi	bluebowl_20020809_down1L	hand putdown bowl	3;drop
40	bluebowl_20020809_down1R	./experiences/bluebowl_20020809_down1R.avi	bluebowl_20020809_down1R	hand putdown bowl	2;
41	bluebowl_20020809_down2R	./experiences/bluebowl_20020809_down2R.avi	bluebowl_20020809_down2R	hand putdown bowl	2;
42	bluebowl_20020809_drop1L	./experiences/bluebowl_20020809_drop1L.avi	bluebowl_20020809_drop1L	hand drop bowl	2;
43	bluebowl_20020809_drop1R	./experiences/bluebowl_20020809_drop1R.avi	bluebowl_20020809_drop1R	hand drop bowl	4;drop
44	bluebowl_20020809_drop2L	./experiences/bluebowl_20020809_drop2L.avi	bluebowl_20020809_drop2L	hand drop bowl	2;
45	bluebowl_20020809_drop2R	./experiences/bluebowl_20020809_drop2R.avi	bluebowl_20020809_drop2R	hand drop bowl	4;drop
46	bluebowl_20020809_pull1L	./experiences/bluebowl_20020809_pull1L.avi	bluebowl_20020809_pull1L	hand pull bowl	2;
47	bluebowl_20020809_pull1R	./experiences/bluebowl_20020809_pull1R.avi	bluebowl_20020809_pull1R	hand pull bowl	2;
48	bluebowl_20020809_pull2L	./experiences/bluebowl_20020809_pull2L.avi	bluebowl_20020809_pull2L	hand pull bowl	2;
49	bluebowl_20020809_pull2R	./experiences/bluebowl_20020809_pull2R.avi	bluebowl_20020809_pull2R	hand pull bowl	2;
50	bluebowl_20020809_push1L	./experiences/bluebowl_20020809_push1L.avi	bluebowl_20020809_push1L	hand push bowl	2;
51	bluebowl_20020809_push1R	./experiences/bluebowl_20020809_push1R.avi	bluebowl_20020809_push1R	hand push bowl	2;
52	bluebowl_20020809_push2L	./experiences/bluebowl_20020809_push2L.avi	bluebowl_20020809_push2L	hand push bowl	2;
53	bluebowl_20020809_push2R	./experiences/bluebowl_20020809_push2R.avi	bluebowl_20020809_push2R	hand push bowl	2;
54	bluebowl_20020809_touch1L	./experiences/bluebowl_20020809_touch1L.avi	bluebowl_20020809_touch1L	hand touch bowl	2;
55	bluebowl_20020809_touch1R	./experiences/bluebowl_20020809_touch1R.avi	bluebowl_20020809_touch1R	hand touch bowl	2;
56	bluebowl_20020809_touch2L	./experiences/bluebowl_20020809_touch2L.avi	bluebowl_20020809_touch2L	hand touch bowl	2;
57	bluebowl_20020809_touch2R	./experiences/bluebowl_20020809_touch2R.avi	bluebowl_20020809_touch2R	hand touch bowl	2;
61	bluebowl_20020809_up2R	./experiences/bluebowl_20020809_up2R.avi	bluebowl_20020809_up2R	hand pickup bowl	2;
62	bluering_20020619_down1L	./experiences/bluering_20020619_down1L.avi	bluering_20020619_down1L	hand putdown ring	4;
63	bluering_20020619_down1R	./experiences/bluering_20020619_down1R.avi	bluering_20020619_down1R	hand putdown ring	4;
64	bluering_20020619_down2L	./experiences/bluering_20020619_down2L.avi	bluering_20020619_down2L	hand putdown ring	4;
65	bluering_20020619_down2R	./experiences/bluering_20020619_down2R.avi	bluering_20020619_down2R	hand putdown ring	4;
66	bluering_20020619_drop1R	./experiences/bluering_20020619_drop1R.avi	bluering_20020619_drop1R	hand drop ring	4;
67	bluering_20020619_drop2R	./experiences/bluering_20020619_drop2R.avi	bluering_20020619_drop2R	hand drop ring	4;
68	bluering_20020619_drop3R	./experiences/bluering_20020619_drop3R.avi	bluering_20020619_drop3R	hand drop ring	4;
69	bluering_20020619_drop4R	./experiences/bluering_20020619_drop4R.avi	bluering_20020619_drop4R	hand drop ring	4;
70	bluering_20020619_pull1L	./experiences/bluering_20020619_pull1L.avi	bluering_20020619_pull1L	hand pull ring	2;
71	bluering_20020619_pull1R	./experiences/bluering_20020619_pull1R.avi	bluering_20020619_pull1R	hand pull ring	2;
72	bluering_20020619_slidel1L	./experiences/bluering_20020619_slidel1L.avi	bluering_20020619_slidel1L	hand slide ring	2;
73	bluering_20020619_slidel1R	./experiences/bluering_20020619_slidel1R.avi	bluering_20020619_slidel1R	hand slide ring	2;
318	vase_20020809_push2L	./experiences/vase_20020809_push2L.avi	vase_20020809_push2L	hand push vase	2;
319	vase_20020809_push2R	./experiences/vase_20020809_push2R.avi	vase_20020809_push2R	hand push vase	2;
320	vase_20020809_touch1L	./experiences/vase_20020809_touch1L.avi	vase_20020809_touch1L	hand touch vase	2;
321	vase_20020809_touch1R	./experiences/vase_20020809_touch1R.avi	vase_20020809_touch1R	hand touch vase	2;
322	vase_20020809_touch2L	./experiences/vase_20020809_touch2L.avi	vase_20020809_touch2L	hand touch vase	2;
323	vase_20020809_touch2R	./experiences/vase_20020809_touch2R.avi	vase_20020809_touch2R	hand touch vase	2;
324	vase_20020809_up1L	./experiences/vase_20020809_up1L.avi	vase_20020809_up1L	hand pickup vase	2;
9	ball_20020619_down1L	./experiences/ball_20020619_down1L.avi	ball_20020619_down1L	hand putdown ball	2;
10	ball_20020619_down1R	./experiences/ball_20020619_down1R.avi	ball_20020619_down1R	hand putdown ball	4;
11	ball_20020619_down2R	./experiences/ball_20020619_down2R.avi	ball_20020619_down2R	hand putdown ball	4;
12	ball_20020619_down3R	./experiences/ball_20020619_down3R.avi	ball_20020619_down3R	hand putdown ball	4;
13	ball_20020619_touch1L	./experiences/ball_20020619_touch1L.avi	ball_20020619_touch1L	hand touch ball	2;
14	ball_20020619_touch1R	./experiences/ball_20020619_touch1R.avi	ball_20020619_touch1R	hand touch ball	2;
15	ball_20020619_touch2L	./experiences/ball_20020619_touch2L.avi	ball_20020619_touch2L	hand touch ball	2;
16	ball_20020619_touch3L	./experiences/ball_20020619_touch3L.avi	ball_20020619_touch3L	hand touch ball	2;
17	ball_20020619_up1L	./experiences/ball_20020619_up1L.avi	ball_20020619_up1L	hand pickup ball	2;
18	ball_20020619_up1R	./experiences/ball_20020619_up1R.avi	ball_20020619_up1R	hand pickup ball	2;
19	ball_20020619_up2L	./experiences/ball_20020619_up2L.avi	ball_20020619_up2L	hand pickup ball	2;
20	ball_20020619_up3L	./experiences/ball_20020619_up3L.avi	ball_20020619_up3L	hand pickup ball	2;
21	ball_20020809_down1R	./experiences/ball_20020809_down1R.avi	ball_20020809_down1R	hand putdown ball	2;
22	ball_20020809_down2R	./experiences/ball_20020809_down2R.avi	ball_20020809_down2R	hand putdown ball	2;
23	ball_20020809_drop1L	./experiences/ball_20020809_drop1L.avi	ball_20020809_drop1L	hand drop ball	2;
24	ball_20020809_drop1R	./experiences/ball_20020809_drop1R.avi	ball_20020809_drop1R	hand drop ball	2;
2	ani_ball_down1	./experiences/ball_down1.avi	ball_down1	hand putdown ball	5;animation
7	ani_cube_slide1	./experiences/cube_slide1.avi	cube_slide1	hand slide cube	5;animation
3	ani_ball_slide1	./experiences/ball_slide1.avi	ball_slide1	hand slide ball	5;animation
\.


--
-- Data for TOC entry 111 (OID 129073)
-- Name: attribute_list_data; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY attribute_list_data (attribute_list_id, description, include_code, type_code, class_name, notes) FROM stdin;
2	grayscale	1	0	\N	grayscale value (0-255)
3	edges	1	0	\N	# edges in polygon
4	relativeCGX	1	0	\N	x coordinate of centroid relative to bounding rectangle, normalized by rectangle width
5	relativeCGY	1	0	\N	y coordinate of centroid relative to bounding rectangle, normalized by rectangle height
6	contact	1	0	\N	0 if bounding rectangles of polygons overlap, 1 otherwise
7	x relation	1	0	\N	-1=o1 left (west) of o2, 0=o1 has same x-coord as o2, 1=o1 right (east) of o2
8	y relation	1	0	\N	-1=o1 over (north) o2, 0=o1 has same y-coord as o2, 1=o1 below (south) o2
9	delta x	1	0	\N	-1=delta x is decreasing, 0=delta x is unchanged, 1=delta x is increasing
10	delta y	1	0	\N	-1=delta y is decreasing, 0=delta y is unchanged, 1=delta y is increasing
11	x travel	1	0	\N	add 1 for each object moving right and subtract 1 for each object moving left
12	y travel	1	0	\N	add 1 for each object moving down and subtract 1 for each object moving up
1	area	1	0	\N	# pixels in polygon
\.


--
-- Data for TOC entry 112 (OID 129080)
-- Name: session_data; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY session_data (session_id, parameter_id, description, session_start, session_stop, regen_int_images_code, log_to_file_code, randomize_exp_code, desc_to_generate, min_sd_start, min_sd_stop, min_sd_step, loop_count, fixed_sd_code, display_movie_code, display_text_code, case_sensitive_code, notes, session_ip) FROM stdin;
\.


--
-- Data for TOC entry 113 (OID 129098)
-- Name: parameter_experience_data; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY parameter_experience_data (parameter_experience_id, parameter_id, experience_id, calc_status_code, calc_timestamp) FROM stdin;
978	11	325	0	2003-05-22 02:39:31.233513
979	11	326	0	2003-05-22 02:41:24.687635
980	11	327	0	2003-05-22 02:44:17.605919
505	13	171	0	2003-05-22 11:52:19.326917
506	13	172	0	2003-05-22 11:54:55.884013
507	13	173	0	2003-05-22 11:57:14.948059
508	13	174	0	2003-05-22 11:59:56.51666
509	13	175	0	2003-05-22 12:03:03.313505
510	13	176	0	2003-05-22 12:06:29.417333
512	13	178	0	2003-05-22 12:08:16.511324
514	13	180	0	2003-05-22 12:10:19.952849
518	13	184	0	2003-05-22 12:12:36.764111
519	13	185	0	2003-05-22 12:15:04.639133
520	13	186	0	2003-05-22 12:16:26.662578
521	13	187	0	2003-05-22 12:18:23.279896
522	13	188	0	2003-05-22 12:20:24.051002
523	13	189	0	2003-05-22 12:22:14.318867
524	13	190	0	2003-05-22 12:23:57.675053
525	13	191	0	2003-05-22 12:26:22.456694
526	13	192	0	2003-05-22 12:28:17.975232
527	13	193	0	2003-05-22 12:30:37.16548
528	13	194	0	2003-05-22 12:32:18.866583
529	13	195	0	2003-05-22 12:34:00.385242
548	13	214	0	2003-05-22 12:36:03.85887
550	13	216	0	2003-05-22 12:38:14.460362
551	13	217	0	2003-05-22 12:40:39.954256
875	11	222	0	2003-05-21 23:59:15.0258
876	11	223	0	2003-05-22 00:01:45.855111
877	11	224	0	2003-05-22 00:04:25.988753
878	11	225	0	2003-05-22 00:06:58.343159
881	11	228	0	2003-05-22 00:09:34.333536
882	11	229	0	2003-05-22 00:11:40.34958
883	11	230	0	2003-05-22 00:14:01.120366
884	11	231	0	2003-05-22 00:16:04.017485
885	11	232	0	2003-05-22 00:18:12.481275
886	11	233	0	2003-05-22 00:20:18.411702
887	11	234	0	2003-05-22 00:24:08.450406
892	11	239	0	2003-05-22 00:26:26.914894
896	11	243	0	2003-05-22 00:28:50.769719
897	11	244	0	2003-05-22 00:30:33.981278
898	11	245	0	2003-05-22 00:32:04.886444
899	11	246	0	2003-05-22 00:34:14.155828
900	11	247	0	2003-05-22 00:36:22.935417
579	13	245	0	2003-05-22 13:11:17.898608
581	13	247	0	2003-05-22 13:13:30.696773
582	13	248	0	2003-05-22 13:16:08.221286
583	13	249	0	2003-05-22 13:19:23.211275
585	13	251	0	2003-05-22 13:21:40.334278
587	13	253	0	2003-05-22 13:22:57.920218
589	13	255	0	2003-05-22 13:24:04.900732
590	13	256	0	2003-05-22 13:25:37.860808
591	13	257	0	2003-05-22 13:27:49.514551
592	13	258	0	2003-05-22 13:29:20.501498
593	13	259	0	2003-05-22 13:31:03.747981
608	13	274	0	2003-05-22 13:33:51.474269
619	13	285	0	2003-05-22 13:34:47.100566
335	9	2	0	2003-05-21 15:58:46.199726
336	9	3	0	2003-05-21 16:00:06.806016
337	9	4	0	2003-05-21 16:01:18.299242
338	9	1	0	2003-05-21 16:02:04.571508
339	9	6	0	2003-05-21 16:03:20.777476
340	9	7	0	2003-05-21 16:04:33.977629
341	9	8	0	2003-05-21 16:05:43.971162
342	9	5	0	2003-05-21 16:06:29.446579
343	13	9	0	2003-05-21 16:42:23.568389
347	13	13	0	2003-05-21 16:45:11.898912
348	13	14	0	2003-05-21 16:47:32.246881
349	13	15	0	2003-05-21 16:49:18.896251
350	13	16	0	2003-05-21 16:51:28.317891
351	13	17	0	2003-05-21 16:53:53.198804
352	13	18	0	2003-05-21 16:56:27.125494
353	13	19	0	2003-05-21 16:58:50.35801
354	13	20	0	2003-05-21 17:01:16.188567
355	13	21	0	2003-05-21 17:03:49.037663
356	13	22	0	2003-05-21 17:06:06.713454
357	13	23	0	2003-05-21 17:08:47.783106
358	13	24	0	2003-05-21 17:10:02.598138
359	13	25	0	2003-05-21 17:11:03.008276
360	13	26	0	2003-05-21 17:12:03.10461
361	13	27	0	2003-05-21 17:13:07.81205
362	13	28	0	2003-05-21 17:14:18.002893
363	13	29	0	2003-05-21 17:15:10.365464
365	13	31	0	2003-05-21 17:16:03.804876
366	13	32	0	2003-05-21 17:18:10.433057
367	13	33	0	2003-05-21 17:20:04.143634
368	13	34	0	2003-05-21 17:22:35.528121
369	13	35	0	2003-05-21 17:24:41.610803
370	13	36	0	2003-05-21 17:27:33.814362
371	13	37	0	2003-05-21 17:29:22.731552
372	13	38	0	2003-05-21 17:31:27.563857
631	13	297	0	2003-05-22 13:37:44.104642
634	13	300	0	2003-05-22 13:40:08.249629
662	11	9	0	2003-05-21 18:05:59.519212
666	11	13	0	2003-05-21 18:08:40.50775
667	11	14	0	2003-05-21 18:10:59.667817
668	11	15	0	2003-05-21 18:12:45.30423
669	11	16	0	2003-05-21 18:14:53.54335
635	13	301	0	2003-05-22 13:43:13.168328
636	13	302	0	2003-05-22 13:46:16.963136
637	13	303	0	2003-05-22 13:49:30.547358
638	13	304	0	2003-05-22 13:52:52.515872
639	13	305	0	2003-05-22 13:55:52.412153
640	13	306	0	2003-05-22 13:57:57.813693
641	13	307	0	2003-05-22 14:00:41.15067
647	13	313	0	2003-05-22 14:03:15.526628
649	13	315	0	2003-05-22 14:05:41.169243
650	13	316	0	2003-05-22 14:08:30.820666
652	13	318	0	2003-05-22 14:10:58.581651
653	13	319	0	2003-05-22 14:13:53.72818
654	13	320	0	2003-05-22 14:16:39.192414
655	13	321	0	2003-05-22 14:19:13.600472
656	13	322	0	2003-05-22 14:21:35.730195
657	13	323	0	2003-05-22 14:25:02.963961
658	13	324	0	2003-05-22 14:27:13.319206
659	13	325	0	2003-05-22 14:32:27.747157
660	13	326	0	2003-05-22 14:34:16.32496
661	13	327	0	2003-05-22 14:36:31.842599
374	13	40	0	2003-05-22 14:39:19.040131
375	13	41	0	2003-05-22 14:41:57.932679
376	13	42	0	2003-05-22 14:44:16.365478
378	13	44	0	2003-05-22 14:45:41.013898
380	13	46	0	2003-05-22 14:47:20.56215
381	13	47	0	2003-05-22 14:50:18.674886
382	13	48	0	2003-05-22 14:52:38.786667
383	13	49	0	2003-05-22 14:55:47.32977
384	13	50	0	2003-05-22 15:02:01.785871
385	13	51	0	2003-05-22 15:04:57.129753
386	13	52	0	2003-05-22 15:07:54.44005
387	13	53	0	2003-05-22 15:10:05.992483
388	13	54	0	2003-05-22 15:12:12.776249
389	13	55	0	2003-05-22 15:14:28.413069
390	13	56	0	2003-05-22 15:16:43.247735
391	13	57	0	2003-05-22 15:19:21.514992
393	13	59	0	2003-05-22 15:21:49.582974
395	13	61	0	2003-05-22 15:24:13.523668
404	13	70	0	2003-05-22 15:26:43.259025
405	13	71	0	2003-05-22 15:28:44.982492
406	13	72	0	2003-05-22 15:31:37.627363
407	13	73	0	2003-05-22 15:33:34.361861
408	13	74	0	2003-05-22 15:35:36.07217
409	13	75	0	2003-05-22 15:37:34.537815
901	11	248	0	2003-05-22 00:38:56.13915
902	11	249	0	2003-05-22 00:42:04.331941
904	11	251	0	2003-05-22 00:44:12.355048
906	11	253	0	2003-05-22 00:45:24.522408
908	11	255	0	2003-05-22 00:46:30.434226
909	11	256	0	2003-05-22 00:48:01.667953
910	11	257	0	2003-05-22 00:50:06.344576
911	11	258	0	2003-05-22 00:51:32.853617
912	11	259	0	2003-05-22 00:53:10.558986
918	11	265	0	2003-05-22 00:55:48.445587
920	11	267	0	2003-05-22 00:58:22.967241
924	11	271	0	2003-05-22 01:01:10.750433
927	11	274	0	2003-05-22 01:05:35.106782
929	11	276	0	2003-05-22 01:06:27.844352
933	11	280	0	2003-05-22 01:07:53.336098
934	11	281	0	2003-05-22 01:10:20.650501
935	11	282	0	2003-05-22 01:12:57.633659
938	11	285	0	2003-05-22 01:15:37.106833
939	11	286	0	2003-05-22 01:18:20.858079
941	11	288	0	2003-05-22 01:20:44.209843
942	11	289	0	2003-05-22 01:25:28.154235
944	11	291	0	2003-05-22 01:29:06.09404
945	11	292	0	2003-05-22 01:31:27.744052
949	11	296	0	2003-05-22 01:34:56.62127
950	11	297	0	2003-05-22 01:37:23.599693
951	11	298	0	2003-05-22 01:39:38.606268
952	11	299	0	2003-05-22 01:42:14.885722
953	11	300	0	2003-05-22 01:45:13.186973
954	11	301	0	2003-05-22 01:48:05.115542
955	11	302	0	2003-05-22 01:51:01.93598
956	11	303	0	2003-05-22 01:54:03.990924
957	11	304	0	2003-05-22 01:57:16.031536
958	11	305	0	2003-05-22 02:00:15.469288
959	11	306	0	2003-05-22 02:02:22.574571
960	11	307	0	2003-05-22 02:04:59.479097
965	11	312	0	2003-05-22 02:07:33.946951
966	11	313	0	2003-05-22 02:10:25.039997
968	11	315	0	2003-05-22 02:12:50.821228
969	11	316	0	2003-05-22 02:15:41.572936
970	11	317	0	2003-05-22 02:18:10.166303
971	11	318	0	2003-05-22 02:20:51.565635
972	11	319	0	2003-05-22 02:23:45.159942
973	11	320	0	2003-05-22 02:26:26.596353
974	11	321	0	2003-05-22 02:29:23.604076
975	11	322	0	2003-05-22 02:31:43.615204
976	11	323	0	2003-05-22 02:35:07.44225
977	11	324	0	2003-05-22 02:37:22.955267
846	11	193	0	2003-05-21 23:08:35.873401
847	11	194	0	2003-05-21 23:10:13.230458
848	11	195	0	2003-05-21 23:11:50.828515
849	11	196	0	2003-05-21 23:13:50.677996
852	11	200	0	2003-05-21 23:15:44.652981
853	11	201	0	2003-05-21 23:18:43.939421
854	11	202	0	2003-05-21 23:21:20.08057
855	11	203	0	2003-05-21 23:22:24.431246
856	11	204	0	2003-05-21 23:24:05.609813
858	11	206	0	2003-05-21 23:25:55.501172
859	11	207	0	2003-05-21 23:28:22.665168
860	11	208	0	2003-05-21 23:30:30.576381
861	11	209	0	2003-05-21 23:32:58.358977
862	11	197	0	2003-05-21 23:35:16.917724
863	11	210	0	2003-05-21 23:37:36.343696
670	11	17	0	2003-05-21 18:17:17.114248
671	11	18	0	2003-05-21 18:19:49.733052
672	11	19	0	2003-05-21 18:22:12.919835
673	11	20	0	2003-05-21 18:24:37.922604
674	11	21	0	2003-05-21 18:27:10.782061
675	11	22	0	2003-05-21 18:29:27.915782
676	11	23	0	2003-05-21 18:32:08.718462
677	11	24	0	2003-05-21 18:33:22.60375
678	11	25	0	2003-05-21 18:34:22.252281
679	11	26	0	2003-05-21 18:35:21.802408
680	11	27	0	2003-05-21 18:36:25.483738
681	11	28	0	2003-05-21 18:37:35.245684
682	11	29	0	2003-05-21 18:38:27.20207
684	11	31	0	2003-05-21 18:39:20.33681
685	11	32	0	2003-05-21 18:41:25.495733
686	11	33	0	2003-05-21 18:43:17.154906
687	11	34	0	2003-05-21 18:45:43.383731
688	11	35	0	2003-05-21 18:47:44.691396
689	11	36	0	2003-05-21 18:50:28.163923
690	11	37	0	2003-05-21 18:52:07.787919
691	11	38	0	2003-05-21 18:53:54.075389
692	11	39	0	2003-05-21 18:55:57.29228
693	11	40	0	2003-05-21 18:58:41.760943
694	11	41	0	2003-05-21 19:01:19.88395
695	11	42	0	2003-05-21 19:03:37.855193
697	11	44	0	2003-05-21 19:05:02.385303
699	11	46	0	2003-05-21 19:06:41.267887
700	11	47	0	2003-05-21 19:09:38.757312
701	11	48	0	2003-05-21 19:11:58.603177
702	11	49	0	2003-05-21 19:15:05.089524
703	11	50	0	2003-05-21 19:18:03.424952
704	11	51	0	2003-05-21 19:20:55.619627
705	11	52	0	2003-05-21 19:23:48.282835
706	11	53	0	2003-05-21 19:25:56.525082
707	11	54	0	2003-05-21 19:28:00.444767
708	11	55	0	2003-05-21 19:30:14.469032
709	11	56	0	2003-05-21 19:32:29.740311
710	11	57	0	2003-05-21 19:35:06.938446
711	11	58	0	2003-05-21 19:37:33.254774
712	11	59	0	2003-05-21 19:40:44.87066
713	11	60	0	2003-05-21 19:43:02.842677
714	11	61	0	2003-05-21 19:45:39.66121
723	11	70	0	2003-05-21 19:48:06.852006
724	11	71	0	2003-05-21 19:50:06.609604
725	11	72	0	2003-05-21 19:52:57.217562
726	11	73	0	2003-05-21 19:54:52.020239
727	11	74	0	2003-05-21 19:56:51.865303
728	11	75	0	2003-05-21 19:58:48.308072
729	11	76	0	2003-05-21 20:01:13.446473
730	11	77	0	2003-05-21 20:02:37.307704
732	11	79	0	2003-05-21 20:05:10.433759
733	11	80	0	2003-05-21 20:07:06.006869
734	11	81	0	2003-05-21 20:08:23.515422
735	11	82	0	2003-05-21 20:10:14.65133
736	11	83	0	2003-05-21 20:11:30.949575
737	11	84	0	2003-05-21 20:12:39.19951
738	11	85	0	2003-05-21 20:14:40.402607
739	11	86	0	2003-05-21 20:16:05.516837
743	11	90	0	2003-05-21 20:18:13.712869
755	11	102	0	2003-05-21 20:19:42.680571
756	11	103	0	2003-05-21 20:21:03.16703
758	11	105	0	2003-05-21 20:22:25.017329
760	11	107	0	2003-05-21 20:24:41.866203
761	11	108	0	2003-05-21 20:26:53.313922
762	11	109	0	2003-05-21 20:29:40.8354
765	11	112	0	2003-05-21 20:32:35.377271
766	11	113	0	2003-05-21 20:36:04.700658
767	11	114	0	2003-05-21 20:39:15.918956
768	11	115	0	2003-05-21 20:42:18.614516
769	11	116	0	2003-05-21 20:45:25.879957
772	11	119	0	2003-05-21 20:49:32.557564
773	11	120	0	2003-05-21 20:51:46.455923
411	13	77	0	2003-05-22 15:41:31.232905
413	13	79	0	2003-05-22 15:44:15.097482
414	13	80	0	2003-05-22 15:46:29.124705
415	13	81	0	2003-05-22 15:47:50.921418
416	13	82	0	2003-05-22 15:49:54.630907
417	13	83	0	2003-05-22 15:51:18.695894
418	13	84	0	2003-05-22 15:52:36.018967
419	13	85	0	2003-05-22 15:54:50.256458
420	13	86	0	2003-05-22 15:56:21.302451
424	13	90	0	2003-05-22 15:58:38.799379
437	13	103	0	2003-05-22 16:00:15.094323
446	13	112	0	2003-05-22 16:01:42.995132
447	13	113	0	2003-05-22 16:05:28.403323
448	13	114	0	2003-05-22 16:08:49.171158
449	13	115	0	2003-05-22 16:12:07.714246
465	13	131	0	2003-05-22 16:15:27.844136
466	13	132	0	2003-05-22 16:18:04.993602
467	13	133	0	2003-05-22 16:21:41.66509
468	13	134	0	2003-05-22 16:25:20.381974
469	13	135	0	2003-05-22 16:28:23.708066
470	13	136	0	2003-05-22 16:31:35.843192
474	13	140	0	2003-05-22 16:33:27.86447
476	13	142	0	2003-05-22 16:36:44.263812
478	13	144	0	2003-05-22 16:38:05.763042
479	13	145	0	2003-05-22 16:40:36.051849
480	13	146	0	2003-05-22 16:43:09.529038
481	13	147	0	2003-05-22 16:45:21.950047
482	13	148	0	2003-05-22 16:48:26.281904
483	13	149	0	2003-05-22 16:50:47.299402
484	13	150	0	2003-05-22 16:53:04.709922
485	13	151	0	2003-05-22 16:54:10.491025
486	13	152	0	2003-05-22 16:56:57.062044
490	13	156	0	2003-05-22 16:58:35.781689
491	13	157	0	2003-05-22 17:01:35.774902
492	13	158	0	2003-05-22 17:05:09.202212
493	13	159	0	2003-05-22 17:08:15.05856
494	13	160	0	2003-05-22 17:11:25.911946
496	13	162	0	2003-05-22 17:13:13.647134
497	13	163	0	2003-05-22 17:14:25.047599
498	13	164	0	2003-05-22 17:15:43.067585
499	13	165	0	2003-05-22 17:18:51.203865
501	13	167	0	2003-05-22 17:21:37.334925
502	13	168	0	2003-05-22 17:26:01.119583
503	13	169	0	2003-05-22 17:28:39.370265
504	13	170	0	2003-05-22 17:31:46.160227
552	13	218	0	2003-05-22 12:42:01.583875
553	13	219	0	2003-05-22 12:43:12.224688
555	13	221	0	2003-05-22 12:44:56.15481
556	13	222	0	2003-05-22 12:47:43.503636
557	13	223	0	2003-05-22 12:50:14.192112
558	13	224	0	2003-05-22 12:52:59.31598
559	13	225	0	2003-05-22 12:55:36.719222
563	13	229	0	2003-05-22 12:58:16.574529
564	13	230	0	2003-05-22 13:00:42.464146
565	13	231	0	2003-05-22 13:02:49.419068
566	13	232	0	2003-05-22 13:05:01.182712
568	13	234	0	2003-05-22 13:07:11.072343
577	13	243	0	2003-05-22 13:09:32.227721
864	11	211	0	2003-05-21 23:39:21.126497
865	11	212	0	2003-05-21 23:42:06.434878
867	11	214	0	2003-05-21 23:44:32.872337
868	11	215	0	2003-05-21 23:46:40.652851
869	11	216	0	2003-05-21 23:49:59.490138
870	11	217	0	2003-05-21 23:52:21.950276
871	11	218	0	2003-05-21 23:53:41.287796
872	11	219	0	2003-05-21 23:54:50.356798
874	11	221	0	2003-05-21 23:56:32.222722
410	13	76	0	2003-05-22 15:40:03.19076
775	11	122	0	2003-05-21 20:55:16.590381
776	11	123	0	2003-05-21 20:58:25.206764
782	11	129	0	2003-05-21 21:01:32.207579
784	11	131	0	2003-05-21 21:03:43.777286
785	11	132	0	2003-05-21 21:06:06.02429
786	11	133	0	2003-05-21 21:09:27.064986
787	11	134	0	2003-05-21 21:12:52.578852
788	11	135	0	2003-05-21 21:15:45.920125
789	11	136	0	2003-05-21 21:18:49.148179
790	11	137	0	2003-05-21 21:20:37.792622
792	11	139	0	2003-05-21 21:23:22.750895
793	11	140	0	2003-05-21 21:25:32.182223
794	11	141	0	2003-05-21 21:28:33.61924
795	11	142	0	2003-05-21 21:31:00.911086
796	11	143	0	2003-05-21 21:32:10.747877
797	11	144	0	2003-05-21 21:34:32.573916
798	11	145	0	2003-05-21 21:36:51.361427
799	11	146	0	2003-05-21 21:39:12.474349
800	11	147	0	2003-05-21 21:41:14.046161
801	11	148	0	2003-05-21 21:43:32.149907
802	11	149	0	2003-05-21 21:45:39.023184
803	11	150	0	2003-05-21 21:47:46.070209
804	11	151	0	2003-05-21 21:48:44.736822
805	11	152	0	2003-05-21 21:51:08.930089
806	11	153	0	2003-05-21 21:52:36.537653
808	11	155	0	2003-05-21 21:54:53.065336
809	11	156	0	2003-05-21 21:56:56.308391
810	11	157	0	2003-05-21 21:59:41.491375
811	11	158	0	2003-05-21 22:02:47.734091
812	11	159	0	2003-05-21 22:05:32.485478
813	11	160	0	2003-05-21 22:08:02.792348
815	11	162	0	2003-05-21 22:09:43.256501
816	11	163	0	2003-05-21 22:10:46.257537
817	11	164	0	2003-05-21 22:11:58.595853
818	11	165	0	2003-05-21 22:15:00.094096
820	11	167	0	2003-05-21 22:17:42.526752
821	11	168	0	2003-05-21 22:21:49.009566
822	11	169	0	2003-05-21 22:24:13.743863
823	11	170	0	2003-05-21 22:26:56.961297
824	11	171	0	2003-05-21 22:29:15.702731
825	11	172	0	2003-05-21 22:31:38.729356
826	11	173	0	2003-05-21 22:33:47.537056
827	11	174	0	2003-05-21 22:36:19.019481
828	11	175	0	2003-05-21 22:39:11.197666
829	11	176	0	2003-05-21 22:42:23.062336
831	11	178	0	2003-05-21 22:44:01.378858
833	11	180	0	2003-05-21 22:45:55.575799
835	11	182	0	2003-05-21 22:48:01.377197
836	11	183	0	2003-05-21 22:49:50.23375
837	11	184	0	2003-05-21 22:51:42.287477
838	11	185	0	2003-05-21 22:53:57.970634
839	11	186	0	2003-05-21 22:55:13.429773
840	11	187	0	2003-05-21 22:57:00.363158
841	11	188	0	2003-05-21 22:58:53.029154
842	11	189	0	2003-05-21 23:00:35.847771
843	11	190	0	2003-05-21 23:02:13.058827
844	11	191	0	2003-05-21 23:04:31.331459
845	11	192	0	2003-05-21 23:06:22.536209
\.


--
-- Data for TOC entry 114 (OID 129105)
-- Name: frame_analysis_data; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY frame_analysis_data (frame_analysis_id, parameter_experience_id, frame_number, object_number, polygon_point_count, polygon_point_list, rgb_color, bound_rect_points, centroid_x, centroid_y, area) FROM stdin;
\.


--
-- Data for TOC entry 115 (OID 129120)
-- Name: run_data; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY run_data (run_id, session_id, run_index, run_start, run_stop, min_sd) FROM stdin;
\.


--
-- Data for TOC entry 116 (OID 129128)
-- Name: entity_data; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY entity_data (entity_id, run_id, occurance_count) FROM stdin;
\.


--
-- Data for TOC entry 117 (OID 129134)
-- Name: lexeme_data; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY lexeme_data (lexeme_id, run_id, lexeme, occurance_count) FROM stdin;
\.


--
-- Data for TOC entry 118 (OID 129140)
-- Name: experience_run_data; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY experience_run_data (experience_run_id, experience_id, run_id, experience_index, experience_description) FROM stdin;
\.


--
-- Data for TOC entry 119 (OID 129146)
-- Name: entity_lexeme_data; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY entity_lexeme_data (entity_lexeme_id, entity_id, lexeme_id, occurance_count) FROM stdin;
\.


--
-- Data for TOC entry 120 (OID 129152)
-- Name: experience_entity_data; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY experience_entity_data (experience_entity_id, experience_id, run_id, entity_id, resolution_code) FROM stdin;
\.


--
-- Data for TOC entry 121 (OID 129158)
-- Name: experience_lexeme_data; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY experience_lexeme_data (experience_lexeme_id, experience_id, run_id, lexeme_id, resolution_code, resolution_index) FROM stdin;
\.


--
-- Data for TOC entry 122 (OID 129165)
-- Name: attribute_value_data; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY attribute_value_data (attribute_value_id, attribute_list_id, run_id, entity_id, avg_value, std_deviation) FROM stdin;
\.


--
-- TOC entry 74 (OID 129913)
-- Name: att_list_description_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX att_list_description_idx ON attribute_list_data USING btree (description);


--
-- TOC entry 77 (OID 129914)
-- Name: session_parameter_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX session_parameter_id_idx ON session_data USING btree (parameter_id);


--
-- TOC entry 79 (OID 129915)
-- Name: para_exp_parameter_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX para_exp_parameter_id_idx ON parameter_experience_data USING btree (parameter_id);


--
-- TOC entry 78 (OID 129916)
-- Name: para_exp_experience_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX para_exp_experience_id_idx ON parameter_experience_data USING btree (experience_id);


--
-- TOC entry 83 (OID 129917)
-- Name: fra_ana_para_exp_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fra_ana_para_exp_id_idx ON frame_analysis_data USING btree (parameter_experience_id);


--
-- TOC entry 81 (OID 129918)
-- Name: fra_ana_frame_number_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fra_ana_frame_number_idx ON frame_analysis_data USING btree (frame_number);


--
-- TOC entry 82 (OID 129919)
-- Name: fra_ana_object_number_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fra_ana_object_number_idx ON frame_analysis_data USING btree (object_number);


--
-- TOC entry 87 (OID 129920)
-- Name: entity_run_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX entity_run_id_idx ON entity_data USING btree (run_id);


--
-- TOC entry 90 (OID 129921)
-- Name: lexeme_run_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX lexeme_run_id_idx ON lexeme_data USING btree (run_id);


--
-- TOC entry 89 (OID 129922)
-- Name: lexeme_lexeme_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX lexeme_lexeme_idx ON lexeme_data USING btree (lexeme);


--
-- TOC entry 91 (OID 129923)
-- Name: exp_run_experience_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX exp_run_experience_id_idx ON experience_run_data USING btree (experience_id);


--
-- TOC entry 92 (OID 129924)
-- Name: exp_run_run_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX exp_run_run_id_idx ON experience_run_data USING btree (run_id);


--
-- TOC entry 94 (OID 129925)
-- Name: ent_lex_entity_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ent_lex_entity_id_idx ON entity_lexeme_data USING btree (entity_id);


--
-- TOC entry 95 (OID 129926)
-- Name: ent_lex_lexeme_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ent_lex_lexeme_id_idx ON entity_lexeme_data USING btree (lexeme_id);


--
-- TOC entry 98 (OID 129927)
-- Name: exp_ent_exp_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX exp_ent_exp_id_idx ON experience_entity_data USING btree (experience_id);


--
-- TOC entry 99 (OID 129928)
-- Name: exp_ent_run_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX exp_ent_run_id_idx ON experience_entity_data USING btree (run_id);


--
-- TOC entry 97 (OID 129929)
-- Name: exp_ent_entity_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX exp_ent_entity_id_idx ON experience_entity_data USING btree (entity_id);


--
-- TOC entry 101 (OID 129930)
-- Name: exp_lex_exp_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX exp_lex_exp_id_idx ON experience_lexeme_data USING btree (experience_id);


--
-- TOC entry 103 (OID 129931)
-- Name: exp_lex_run_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX exp_lex_run_id_idx ON experience_lexeme_data USING btree (run_id);


--
-- TOC entry 102 (OID 129932)
-- Name: exp_lex_lexeme_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX exp_lex_lexeme_id_idx ON experience_lexeme_data USING btree (lexeme_id);


--
-- TOC entry 105 (OID 129933)
-- Name: att_val_attribute_list_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX att_val_attribute_list_id_idx ON attribute_value_data USING btree (attribute_list_id);


--
-- TOC entry 107 (OID 129934)
-- Name: att_val_run_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX att_val_run_id_idx ON attribute_value_data USING btree (run_id);


--
-- TOC entry 106 (OID 129935)
-- Name: att_val_entity_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX att_val_entity_id_idx ON attribute_value_data USING btree (entity_id);


--
-- TOC entry 72 (OID 129936)
-- Name: parameter_data_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY parameter_data
    ADD CONSTRAINT parameter_data_pkey PRIMARY KEY (parameter_id);


--
-- TOC entry 73 (OID 129938)
-- Name: experience_data_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY experience_data
    ADD CONSTRAINT experience_data_pkey PRIMARY KEY (experience_id);


--
-- TOC entry 75 (OID 129940)
-- Name: attribute_list_data_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY attribute_list_data
    ADD CONSTRAINT attribute_list_data_pkey PRIMARY KEY (attribute_list_id);


--
-- TOC entry 76 (OID 129942)
-- Name: session_data_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY session_data
    ADD CONSTRAINT session_data_pkey PRIMARY KEY (session_id);


--
-- TOC entry 123 (OID 129944)
-- Name: $1; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY session_data
    ADD CONSTRAINT "$1" FOREIGN KEY (parameter_id) REFERENCES parameter_data(parameter_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 80 (OID 129948)
-- Name: parameter_experience_data_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY parameter_experience_data
    ADD CONSTRAINT parameter_experience_data_pkey PRIMARY KEY (parameter_experience_id);


--
-- TOC entry 124 (OID 129950)
-- Name: $1; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY parameter_experience_data
    ADD CONSTRAINT "$1" FOREIGN KEY (parameter_id) REFERENCES parameter_data(parameter_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 125 (OID 129954)
-- Name: $2; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY parameter_experience_data
    ADD CONSTRAINT "$2" FOREIGN KEY (experience_id) REFERENCES experience_data(experience_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 84 (OID 129958)
-- Name: frame_analysis_data_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY frame_analysis_data
    ADD CONSTRAINT frame_analysis_data_pkey PRIMARY KEY (frame_analysis_id);


--
-- TOC entry 126 (OID 129960)
-- Name: $1; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY frame_analysis_data
    ADD CONSTRAINT "$1" FOREIGN KEY (parameter_experience_id) REFERENCES parameter_experience_data(parameter_experience_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 85 (OID 129964)
-- Name: run_data_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY run_data
    ADD CONSTRAINT run_data_pkey PRIMARY KEY (run_id);


--
-- TOC entry 127 (OID 129966)
-- Name: $1; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY run_data
    ADD CONSTRAINT "$1" FOREIGN KEY (session_id) REFERENCES session_data(session_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 86 (OID 129970)
-- Name: entity_data_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY entity_data
    ADD CONSTRAINT entity_data_pkey PRIMARY KEY (entity_id);


--
-- TOC entry 128 (OID 129972)
-- Name: $1; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY entity_data
    ADD CONSTRAINT "$1" FOREIGN KEY (run_id) REFERENCES run_data(run_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 88 (OID 129976)
-- Name: lexeme_data_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY lexeme_data
    ADD CONSTRAINT lexeme_data_pkey PRIMARY KEY (lexeme_id);


--
-- TOC entry 129 (OID 129978)
-- Name: $1; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY lexeme_data
    ADD CONSTRAINT "$1" FOREIGN KEY (run_id) REFERENCES run_data(run_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 93 (OID 129982)
-- Name: experience_run_data_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY experience_run_data
    ADD CONSTRAINT experience_run_data_pkey PRIMARY KEY (experience_run_id);


--
-- TOC entry 130 (OID 129984)
-- Name: $1; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY experience_run_data
    ADD CONSTRAINT "$1" FOREIGN KEY (experience_id) REFERENCES experience_data(experience_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 131 (OID 129988)
-- Name: $2; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY experience_run_data
    ADD CONSTRAINT "$2" FOREIGN KEY (run_id) REFERENCES run_data(run_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 96 (OID 129992)
-- Name: entity_lexeme_data_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY entity_lexeme_data
    ADD CONSTRAINT entity_lexeme_data_pkey PRIMARY KEY (entity_lexeme_id);


--
-- TOC entry 132 (OID 129994)
-- Name: $1; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY entity_lexeme_data
    ADD CONSTRAINT "$1" FOREIGN KEY (entity_id) REFERENCES entity_data(entity_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 133 (OID 129998)
-- Name: $2; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY entity_lexeme_data
    ADD CONSTRAINT "$2" FOREIGN KEY (lexeme_id) REFERENCES lexeme_data(lexeme_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 100 (OID 130002)
-- Name: experience_entity_data_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY experience_entity_data
    ADD CONSTRAINT experience_entity_data_pkey PRIMARY KEY (experience_entity_id);


--
-- TOC entry 134 (OID 130004)
-- Name: $1; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY experience_entity_data
    ADD CONSTRAINT "$1" FOREIGN KEY (experience_id) REFERENCES experience_data(experience_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 135 (OID 130008)
-- Name: $2; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY experience_entity_data
    ADD CONSTRAINT "$2" FOREIGN KEY (run_id) REFERENCES run_data(run_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 136 (OID 130012)
-- Name: $3; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY experience_entity_data
    ADD CONSTRAINT "$3" FOREIGN KEY (entity_id) REFERENCES entity_data(entity_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 104 (OID 130016)
-- Name: experience_lexeme_data_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY experience_lexeme_data
    ADD CONSTRAINT experience_lexeme_data_pkey PRIMARY KEY (experience_lexeme_id);


--
-- TOC entry 137 (OID 130018)
-- Name: $1; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY experience_lexeme_data
    ADD CONSTRAINT "$1" FOREIGN KEY (experience_id) REFERENCES experience_data(experience_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 138 (OID 130022)
-- Name: $2; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY experience_lexeme_data
    ADD CONSTRAINT "$2" FOREIGN KEY (run_id) REFERENCES run_data(run_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 139 (OID 130026)
-- Name: $3; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY experience_lexeme_data
    ADD CONSTRAINT "$3" FOREIGN KEY (lexeme_id) REFERENCES lexeme_data(lexeme_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 108 (OID 130030)
-- Name: attribute_value_data_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY attribute_value_data
    ADD CONSTRAINT attribute_value_data_pkey PRIMARY KEY (attribute_value_id);


--
-- TOC entry 140 (OID 130032)
-- Name: $1; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY attribute_value_data
    ADD CONSTRAINT "$1" FOREIGN KEY (attribute_list_id) REFERENCES attribute_list_data(attribute_list_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 141 (OID 130036)
-- Name: $2; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY attribute_value_data
    ADD CONSTRAINT "$2" FOREIGN KEY (run_id) REFERENCES run_data(run_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 142 (OID 130040)
-- Name: $3; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY attribute_value_data
    ADD CONSTRAINT "$3" FOREIGN KEY (entity_id) REFERENCES entity_data(entity_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3 (OID 129052)
-- Name: parameter_data_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval ('parameter_data_seq', 13, true);


--
-- TOC entry 6 (OID 129066)
-- Name: experience_data_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval ('experience_data_seq', 327, true);


--
-- TOC entry 9 (OID 129071)
-- Name: attribute_list_data_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval ('attribute_list_data_seq', 12, true);


--
-- TOC entry 12 (OID 129078)
-- Name: session_data_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval ('session_data_seq', 113, true);


--
-- TOC entry 15 (OID 129096)
-- Name: parameter_experience_data_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval ('parameter_experience_data_seq', 980, true);


--
-- TOC entry 18 (OID 129103)
-- Name: frame_analysis_data_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval ('frame_analysis_data_seq', 24888, true);


--
-- TOC entry 21 (OID 129118)
-- Name: run_data_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval ('run_data_seq', 147, true);


--
-- TOC entry 24 (OID 129126)
-- Name: entity_data_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval ('entity_data_seq', 1474, true);


--
-- TOC entry 27 (OID 129132)
-- Name: lexeme_data_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval ('lexeme_data_seq', 1048, true);


--
-- TOC entry 30 (OID 129138)
-- Name: experience_run_data_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval ('experience_run_data_seq', 1691, true);


--
-- TOC entry 33 (OID 129144)
-- Name: entity_lexeme_data_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval ('entity_lexeme_data_seq', 1409, true);


--
-- TOC entry 36 (OID 129150)
-- Name: experience_entity_data_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval ('experience_entity_data_seq', 4500, true);


--
-- TOC entry 39 (OID 129156)
-- Name: experience_lexeme_data_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval ('experience_lexeme_data_seq', 5049, true);


--
-- TOC entry 42 (OID 129163)
-- Name: attribute_value_data_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval ('attribute_value_data_seq', 8696, true);


